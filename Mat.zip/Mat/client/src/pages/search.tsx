import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { Search as SearchIcon, SlidersHorizontal, Music, Moon, Sun, Info, Mail } from "lucide-react";
import { useTheme } from "next-themes";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SearchResult } from "@shared/schema";
import { SearchResultCard } from "@/components/search-result-card";
import { FilterPanel } from "@/components/filter-panel";
import { MusicPlayer } from "@/components/music-player";
import { VibeMatchModal } from "@/components/vibe-match-modal";

export default function SearchPage() {
  const [, setLocation] = useLocation();
  const searchParams = new URLSearchParams(useSearch());
  const initialQuery = searchParams.get("q") || "";
  
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeQuery, setActiveQuery] = useState(initialQuery);
  const [showFilters, setShowFilters] = useState(false);
  const [showVibeMatch, setShowVibeMatch] = useState(false);
  const [sortBy, setSortBy] = useState<"relevance" | "newest" | "popularity" | "publicDomain">("relevance");
  const [platform, setPlatform] = useState<"all" | "youtube" | "soundcloud">("all");
  const [currentTrack, setCurrentTrack] = useState<SearchResult | null>(null);
  const { theme, setTheme } = useTheme();

  const { data: results, isLoading } = useQuery<SearchResult[]>({
    queryKey: [`/api/search?q=${encodeURIComponent(activeQuery)}&sortBy=${sortBy}&platform=${platform}`],
    enabled: !!activeQuery,
  });

  useEffect(() => {
    setSearchQuery(initialQuery);
    setActiveQuery(initialQuery);
  }, [initialQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveQuery(searchQuery.trim());
      setLocation(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handlePlayTrack = (result: SearchResult) => {
    setCurrentTrack(result);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header with search */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-background/30 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setLocation("/")}
              className="text-2xl font-display font-semibold bg-gradient-to-r from-violet-500 to-blue-500 bg-clip-text text-transparent hover-elevate"
              data-testid="link-home"
            >
              Mate
            </button>
            
            <form onSubmit={handleSearch} className="flex-1 max-w-2xl">
              <div className="glass rounded-xl px-4 py-2 flex items-center gap-2">
                <SearchIcon className="w-4 h-4 text-muted-foreground" />
                <Input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for songs..."
                  className="flex-1 bg-transparent border-0 focus-visible:ring-0 text-sm"
                  data-testid="input-search-page"
                />
              </div>
            </form>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/about")}
              className="text-violet-400 hover:text-violet-300"
            >
              <Info className="w-4 h-4 mr-2" />
              About
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/contact")}
              className="text-violet-400 hover:text-violet-300"
            >
              <Mail className="w-4 h-4 mr-2" />
              Contact
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowFilters(!showFilters)}
              className="text-violet-400"
              data-testid="button-filters"
            >
              <SlidersHorizontal className="w-5 h-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowVibeMatch(true)}
              className="text-violet-400"
              data-testid="button-vibe-match-search"
            >
              <Music className="w-5 h-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="text-violet-400"
            >
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8 pb-32">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="glass rounded-xl h-64 animate-pulse" />
            ))}
          </div>
        ) : results && results.length > 0 ? (
          <>
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Found {results.length} results for "{activeQuery}"
              </p>
              <p className="text-sm text-muted-foreground">
                Sorted by: <span className="text-foreground capitalize">{sortBy}</span>
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((result) => (
                <SearchResultCard
                  key={result.id}
                  result={result}
                  onPlay={handlePlayTrack}
                  isPlaying={currentTrack?.id === result.id}
                />
              ))}
            </div>
          </>
        ) : activeQuery ? (
          <div className="text-center py-20 space-y-4">
            <Music className="w-16 h-16 mx-auto text-muted-foreground" />
            <h3 className="text-xl font-display">No results found</h3>
            <p className="text-muted-foreground">
              Try different keywords or use Vibe Match to find similar songs
            </p>
          </div>
        ) : null}
      </main>

      {/* Filter panel */}
      <FilterPanel
        open={showFilters}
        onOpenChange={setShowFilters}
        sortBy={sortBy}
        setSortBy={setSortBy}
        platform={platform}
        setPlatform={setPlatform}
      />

      {/* Music player */}
      {currentTrack && (
        <MusicPlayer
          track={currentTrack}
          onClose={() => setCurrentTrack(null)}
        />
      )}

      {/* Vibe match modal */}
      <VibeMatchModal
        open={showVibeMatch}
        onOpenChange={setShowVibeMatch}
      />
    </div>
  );
}
