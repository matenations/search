import { useState, useRef, useEffect } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, X, BarChart3 } from "lucide-react";
import { SiYoutube, SiSoundcloud } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { SearchResult } from "@shared/schema";

interface MusicPlayerProps {
  track: SearchResult;
  onClose: () => void;
}

export function MusicPlayer({ track, onClose }: MusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showVisualizer, setShowVisualizer] = useState(true);
  const [volume, setVolume] = useState(70);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    // Start visualizer animation when playing
    if (isPlaying && showVisualizer) {
      visualize();
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, showVisualizer]);

  const visualize = () => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const bufferLength = 64;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationFrameRef.current = requestAnimationFrame(draw);
      
      // Simulate audio data with random values when playing
      if (isPlaying) {
        for (let i = 0; i < bufferLength; i++) {
          dataArray[i] = Math.random() * 200 + 55;
        }
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / bufferLength) * 1.5;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height * 0.8;
        
        const gradient = ctx.createLinearGradient(0, canvas.height - barHeight, 0, canvas.height);
        gradient.addColorStop(0, "rgb(139, 92, 246)");
        gradient.addColorStop(1, "rgb(59, 130, 246)");
        
        ctx.fillStyle = gradient;
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 2, barHeight);

        x += barWidth;
      }
    };

    draw();
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleOpenSource = () => {
    window.open(track.url, "_blank", "noopener,noreferrer");
  };

  // Build YouTube embed URL with autoplay
  const getEmbedUrl = () => {
    if (track.platform === "youtube") {
      const videoId = track.id;
      return `https://www.youtube.com/embed/${videoId}?autoplay=${isPlaying ? 1 : 0}&enablejsapi=1&origin=${window.location.origin}`;
    }
    return track.embedUrl || track.url;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 glass-elevated border-t border-white/20 animate-in slide-in-from-bottom duration-300">
      {/* Hidden iframe for YouTube player */}
      <div className="hidden">
        <iframe
          ref={iframeRef}
          src={getEmbedUrl()}
          allow="autoplay; encrypted-media"
          title="Music Player"
        />
      </div>

      {/* Visualizer */}
      {showVisualizer && (
        <div className="h-16 border-b border-white/10">
          <canvas
            ref={canvasRef}
            width={1200}
            height={64}
            className="w-full h-full"
          />
        </div>
      )}

      <div className="px-6 py-4">

        <div className="flex items-center gap-4">
          {/* Track info */}
          <div className="flex items-center gap-4 flex-1 min-w-0">
            <img
              src={track.thumbnail}
              alt={track.title}
              className="w-16 h-16 rounded-lg object-cover"
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-medium truncate" data-testid="text-player-title">
                {track.title}
              </h3>
              <p className="text-sm text-muted-foreground truncate" data-testid="text-player-artist">
                {track.artist}
              </p>
            </div>
          </div>

          {/* Playback controls */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              disabled
              className="text-muted-foreground"
            >
              <SkipBack className="w-5 h-5" />
            </Button>
            
            <Button
              size="icon"
              onClick={togglePlay}
              className="w-12 h-12 bg-gradient-to-r from-violet-500 to-blue-500 hover:from-violet-600 hover:to-blue-600"
              data-testid="button-play-pause"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6" />
              ) : (
                <Play className="w-6 h-6 ml-0.5" />
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              disabled
              className="text-muted-foreground"
            >
              <SkipForward className="w-5 h-5" />
            </Button>
          </div>

          {/* Volume and actions */}
          <div className="flex items-center gap-4 flex-1 justify-end">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-muted-foreground" />
              <Slider
                value={[volume]}
                max={100}
                step={1}
                onValueChange={([value]) => setVolume(value)}
                className="w-24"
                data-testid="slider-volume"
              />
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowVisualizer(!showVisualizer)}
              className={showVisualizer ? "text-violet-400" : "text-muted-foreground"}
              data-testid="button-toggle-visualizer"
            >
              <BarChart3 className="w-5 h-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={handleOpenSource}
              className="text-muted-foreground hover:text-foreground"
              data-testid="button-open-source"
            >
              {track.platform === "youtube" ? (
                <SiYoutube className="w-5 h-5" />
              ) : (
                <SiSoundcloud className="w-5 h-5" />
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-player"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
