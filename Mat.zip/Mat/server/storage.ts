// Storage is not needed for this music search application
// All data comes from external APIs (YouTube, SoundCloud, OpenAI)

export interface IStorage {
  // Placeholder for future features like saved playlists
}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
