import type { Express } from "express";
import { createServer, type Server } from "http";
import { searchYouTube } from "./lib/youtube";
import { searchSoundCloud } from "./lib/soundcloud";
import { analyzeVibeFromAudio, recognizeAudio } from "./lib/openai-service";
import { searchQuerySchema, vibeMatchRequestSchema, audioRecognitionRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Search endpoint - searches across YouTube and SoundCloud
  app.get("/api/search", async (req, res) => {
    try {
      const params = searchQuerySchema.parse({
        query: req.query.q,
        sortBy: req.query.sortBy || "relevance",
        platform: req.query.platform || "all",
      });

      let results: any[] = [];

      // Search YouTube
      if (params.platform === "all" || params.platform === "youtube") {
        try {
          const youtubeResults = await searchYouTube(params.query);
          results = [...results, ...youtubeResults.map(r => ({ ...r, platform: "youtube" }))];
        } catch (error) {
          console.error("YouTube search failed:", error);
        }
      }

      // Search SoundCloud
      if (params.platform === "all" || params.platform === "soundcloud") {
        try {
          const soundcloudResults = await searchSoundCloud(params.query);
          results = [...results, ...soundcloudResults.map(r => ({ ...r, platform: "soundcloud" }))];
        } catch (error) {
          console.error("SoundCloud search failed:", error);
        }
      }

      // Sort results
      switch (params.sortBy) {
        case "newest":
          results.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
          break;
        case "popularity":
          results.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0));
          break;
        case "publicDomain":
          // Filter for Creative Commons or public domain (simplified)
          results = results.filter(r => 
            r.description?.toLowerCase().includes("creative commons") ||
            r.description?.toLowerCase().includes("public domain")
          );
          break;
        case "relevance":
        default:
          // YouTube already returns by relevance, SoundCloud would too
          break;
      }

      res.json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid search parameters", details: error.errors });
      } else {
        console.error("Search error:", error);
        res.status(500).json({ error: "Search failed" });
      }
    }
  });

  // Vibe Match endpoint - AI-powered vibe matching
  app.post("/api/vibe-match", async (req, res) => {
    try {
      const { audioData } = vibeMatchRequestSchema.parse(req.body);

      const result = await analyzeVibeFromAudio(audioData);

      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request", details: error.errors });
      } else {
        console.error("Vibe match error:", error);
        res.status(500).json({ error: "Vibe matching failed" });
      }
    }
  });

  // Audio Recognition endpoint - Shazam-like functionality
  app.post("/api/recognize", async (req, res) => {
    try {
      const { audioData } = audioRecognitionRequestSchema.parse(req.body);

      const result = await recognizeAudio(audioData);

      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request", details: error.errors });
      } else {
        console.error("Audio recognition error:", error);
        res.status(500).json({ error: "Audio recognition failed" });
      }
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
