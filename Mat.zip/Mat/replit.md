# Mate - Music Search Engine

## Overview
Mate is a powerful music search engine with AI-powered vibe matching capabilities. Built with a stunning violet and dark blue themed interface inspired by jeton.com, featuring glassmorphism effects and smooth animations.

## Key Features

### Core Functionality
- **Multi-Platform Search**: Search across YouTube (and SoundCloud when available)
- **AI Vibe Match**: Record yourself humming and let AI identify the vibe to find similar songs
- **Advanced Filtering**: Sort by relevance, newest, popularity, or public domain
- **In-App Music Player**: Beautiful player with NCS-style visualizer
- **Audio Recognition**: Shazam-like song identification from audio clips

### Technology Stack
**Frontend**:
- React + TypeScript
- Tailwind CSS with custom violet/blue theme
- Framer Motion for smooth animations
- Web Audio API for visualizations
- TanStack Query for data fetching
- Wouter for routing

**Backend**:
- Express.js
- YouTube Data API v3 (via Replit integration)
- OpenAI GPT-5 for vibe analysis (200+ musical vibes)
- Whisper API for audio transcription

## Architecture

### Data Flow
1. User searches or uses Vibe Match
2. Frontend sends query to backend API
3. Backend searches YouTube/processes AI request
4. Results displayed in glassmorphic cards
5. User clicks to play - opens in embedded player with visualizer

### Key Files
- `client/src/pages/home.tsx` - Landing page with hero search
- `client/src/pages/search.tsx` - Search results page
- `client/src/components/music-player.tsx` - Music player with visualizer
- `client/src/components/vibe-match-modal.tsx` - AI vibe matching interface
- `server/lib/youtube.ts` - YouTube API integration
- `server/lib/openai-service.ts` - AI vibe analysis
- `shared/schema.ts` - Type definitions

### Design System
- **Primary Colors**: Violet (270° 60% 55%) and Blue (240° 70% 50%)
- **Background**: Deep violet-blue (230° 35% 8%)
- **Typography**: Inter (body), Poppins (display), JetBrains Mono (mono)
- **Effects**: Glassmorphism with backdrop-blur, gradient animations

## Recent Changes (October 4, 2025)
- Implemented complete frontend with jeton.com-inspired animations
- Integrated YouTube Data API for music search
- Added OpenAI GPT-5 powered vibe matching with 200+ vibes
- Built custom music player with visualizer
- Configured dark mode violet/blue theme
- Added advanced filtering and sorting options
- Set up Replit environment with proper Vite configuration for proxy support
- Configured deployment settings for autoscale deployment
- Made OpenAI and database dependencies lazy-loaded to allow app startup without secrets

## Environment Variables & Integrations
- `OPENAI_API_KEY`: OpenAI API key for vibe matching (required for AI features)
  - Set this up via Replit Secrets
  - The app will run without it, but AI features will fail gracefully
- YouTube API: Set up via Replit YouTube connector
  - The app needs YouTube connector configured for music search to work
- `DATABASE_URL`: PostgreSQL database (optional, configured but not used currently)
- `SESSION_SECRET`: Session secret for Express (auto-generated if not set)

## Future Enhancements
- User accounts with saved playlists
- SoundCloud API integration (requires OAuth setup)
- Real-time collaborative playlists
- Lyrics display with synchronized highlighting
- Download functionality for public domain tracks
- Enhanced audio recognition using dedicated services
